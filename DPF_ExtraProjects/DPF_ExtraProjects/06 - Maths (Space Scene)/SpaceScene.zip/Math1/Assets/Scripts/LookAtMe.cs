﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookAtMe : MonoBehaviour
{

    public Transform lookAtMe;
    void Update()
    {
        transform.LookAt(lookAtMe);
        Debug.DrawLine(transform.position, lookAtMe.position, Color.green);
    }
}

