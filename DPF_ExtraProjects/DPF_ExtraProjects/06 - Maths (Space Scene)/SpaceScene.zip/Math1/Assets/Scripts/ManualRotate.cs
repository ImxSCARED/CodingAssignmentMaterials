﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManualRotate : MonoBehaviour
{

    public float rotationSpeed = 300;

    float rotationX = 0;
    float rotationY = 0;
    float rotationZ = 0;

    float speed = 1;

    void Update()
    {

        rotationX += Input.GetAxis("Mouse X") * Time.deltaTime * rotationSpeed;
        rotationY += Input.GetAxis("Mouse Y") * Time.deltaTime * rotationSpeed;
        rotationZ += Input.GetAxis("Mouse ScrollWheel") * Time.deltaTime * rotationSpeed * 40;
        transform.rotation = Quaternion.Euler(rotationX, rotationY, rotationZ);

        transform.position += transform.forward * Time.deltaTime * speed;
    }
}

